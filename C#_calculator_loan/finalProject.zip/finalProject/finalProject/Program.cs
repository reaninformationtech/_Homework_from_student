﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double loanMoney;
            double loanRate;
            int termLoan;
            DateTime startBorrowDate = new DateTime(2022, 11, 04);

            Console.Write("Enter Loan Money :");
            loanMoney = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Loan Rate :");
            loanRate = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Term Loan :");
            termLoan = Convert.ToInt16(Console.ReadLine());


            DateTime endDate;
            double payment = 0;
            double interest = 0;
            double principal = 0;
            double balance = 0;
            principal = loanMoney / termLoan;
            double interestPerDay = 0;
            double totalPayment = 0;
            double totalInterest = 0;
            totalPayment = principal + interest;
            

            Console.WriteLine("------------------------------------------------Schedule Payment--------------------------------------------");
            Console.WriteLine("\t\t\t\t\tLoan Mone :" + loanMoney.ToString("#,##0.00") + "\tLoan Rate :" + loanRate.ToString());
            Console.WriteLine("\t\t\t\t\tBorrow Date :" + startBorrowDate.ToString("dd-MM-yyyy") + "\tTeam Loan :" + termLoan.ToString());
            Console.WriteLine("------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("N\tDate of Payment\t\t\tPayments\tInterest\tPrincipal\tBalance");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------");

            endDate = startBorrowDate.AddMonths(1);
            for (int i = 1; i <= termLoan; i++)
            {
                totalPayment = totalPayment + payment;
                totalInterest = totalInterest + interest;
                interestPerDay = (loanMoney * loanRate) / 100 / 30;


                if (i >1)
                {
                    endDate = endDate.AddMonths(1);
                }


                if (endDate.DayOfWeek == DayOfWeek.Saturday)
                {
                    endDate = endDate.AddDays(2);
                    interest = interestPerDay * 32;

                }
                else if (endDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    endDate = endDate.AddDays(1);
                    interest = interestPerDay * 31;
                }
                else
                {

                    
                    interest = interestPerDay * 30;
                }

                
                payment = principal + interest;
                balance = loanMoney - principal;
                loanMoney = balance;

                Console.WriteLine(i + "\t" + endDate.ToString("dddd dd-MM-yyyy") + "\t\t" + payment.ToString("#,##0.00") + "\t\t"
                        + interest.ToString("#,##0.00") + "\t\t" + principal.ToString("#,##0.00") + "\t\t" + balance.ToString("#,##0.00"));
                Console.WriteLine("------------------------------------------------------------------------------------------------------------");
            }
            
            Console.WriteLine( "\t\t\t TotalPayment:" + totalPayment.ToString("#,##0.00") + "\t\t" + totalInterest.ToString("#,##0.00")) ;
            
            Console.ReadKey();
        }
    }
}
